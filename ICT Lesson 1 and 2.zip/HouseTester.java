/**
 *<BR> Name:          First Last
 *<BR> Date:          0-00-0000
 *<BR> Period:        0
 *<BR> Assignment:    Lesson00
 *<BR> Description:   In a sentence, what does this code do?
 *<BR> Cite Sources:  Everyone who helped, and/or websites used
 */

import gpdraw.*;

public class HouseTester
{
    public static void main(String[] args)
    {
        House MyHouse = new House();
        MyHouse.draw();
    }
}
/*
RUN OUTPUT:

*/