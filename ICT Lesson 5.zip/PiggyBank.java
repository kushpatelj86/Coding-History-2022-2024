/**
 *<BR> Name:          Kush Patel
 *<BR> Date:          10-05-2021
 *<BR> Period:        2
 *<BR> Assignment:    ICT Lesson 5.1
 *<BR> Description:   In this assignment we will be testing and calculation the miles per gallon for 3 differnt cars at 4 different Filling Station Visit
 *<BR> Cite Sources:  Mr.Eliot taught me what to put in the contructor methods, Websites I used:https://www.youtube.com/watch?v=OwutNVAINOs and https://www.guinnessworldrecords.com/world-records/highest-vehicle-mileage
 */



public class PiggyBank 
{
    /// private primitve values
    private int myPennies;
    private int myNickels;
    private int myDimes;
    private int myQuarters;
    private int myHalfDollars;
    private int myDollars;
    private String MyName;

    /// constructor method
    public PiggyBank()
    {
        MyName = "Obipig Pigoby";
        myPennies = 0;
        myNickels = 0;
        myDimes = 0;
        myQuarters = 0;
        myHalfDollars = 0;
        myDollars = 0;
    }

    public PiggyBank(String Name, int pennies, int nickels, int dimes, int quarters, int halfDollars, int dollars)
    {
        MyName = Name;
        myPennies = pennies;
        myNickels = nickels;
        myDimes = dimes;
        myQuarters = quarters;
        myHalfDollars = halfDollars;
        myDollars = dollars; 
    }

    public PiggyBank(PiggyBank OtherPiggyBank)
    {
        myPennies = OtherPiggyBank.getPennies();
        myNickels = OtherPiggyBank.getNickels();
        myDimes = OtherPiggyBank.getDimes();
        myQuarters = OtherPiggyBank.getQuarters();
        myHalfDollars = OtherPiggyBank.getHalfDollars();
        myDollars = OtherPiggyBank.getDollars();
    }

    public PiggyBank(String Name, PiggyBank OtherPiggyBank)
    {
        MyName = Name;
        myPennies = OtherPiggyBank.getPennies();
        myNickels = OtherPiggyBank.getNickels();
        myDimes = OtherPiggyBank.getDimes();
        myQuarters = OtherPiggyBank.getQuarters();
        myHalfDollars = OtherPiggyBank.getHalfDollars();
        myDollars = OtherPiggyBank.getDollars();
    }
    
    public void printPiggyBank()
    {
        System.out.println("Name: " + getName());
        System.out.println("Current # of Pennies is " + getPennies());
        System.out.println("Current # of Nickels is " + getNickels());
        System.out.println("Current # of Dimes is " + getDimes());
        System.out.println("Current # of Quarters is " + getQuarters());
        System.out.println("Current # of Half-Dollars is " + getHalfDollars());
        System.out.println("Current # of Dollars is " + getDollars());
        System.out.println("Current Dollar Amount is $" + calculatePiggyBankBalance());
    }

    
    public void depositCoins(int pennies, int nickels, int dimes, int quarters, int halfDollars, int dollars)
    {
        myPennies += pennies;
        myNickels += nickels;
        myDimes += dimes;
        myQuarters += quarters;
        myHalfDollars += halfDollars;
        myDollars += dollars;
    }

    public void depositNickels(int nickels)
    {
        myNickels += nickels;
    }

    public void depositPennies(int pennies)
    {
        myPennies += pennies;
    }

    public void depositDimes(int dimes)
    {
        myDimes += dimes;
    }

    public void depositQuarters(int quarters)
    {
        myQuarters += quarters;
    }

    public void depositHalfDollars(int halfDollars)
    {
        myHalfDollars += halfDollars;
    }

    public void depositDollars(int dollars)
    {
        myDollars += dollars;
    }

    
    public void withdrawNickels(int nickels)
    {
        myNickels -= nickels;
    }

    public void withdrawPennies(int pennies)
    {
        myPennies -= pennies;
    }

    public void withdrawDimes(int dimes)
    {
        myDimes -= dimes;
    }

    public void withdrawQuarters(int quarters)
    {
        myQuarters -= quarters;
    }

    public void withdrawHalfDollars(int halfDollars)
    {
        myHalfDollars -= halfDollars;
    }

    public void withdrawDollars(int dollars)
    {
        myDollars -= dollars;
    }
    
    public void withdrawCoins(int pennies, int nickels, int dimes, int quarters, int halfDollars, int dollars)
    {
        myPennies -= pennies;
        myNickels -= nickels;
        myDimes -= dimes;
        myQuarters -= quarters;
        myHalfDollars -= halfDollars;
        myDollars -= dollars;
    }
    
    public double calculatePiggyBankBalance()
    {
        double myPiggyBankBalance;   
        myPiggyBankBalance = (myPennies * 0.01) + (myNickels * 0.05) + (myDimes * 0.10) + (myQuarters * 0.25) + (myHalfDollars * 0.50) + (myDollars * 1.00);
        myPiggyBankBalance = roundTwoDecimals(myPiggyBankBalance);
        return myPiggyBankBalance;
    }
    

    private double roundTwoDecimals(double amount)
    {
        double roundedAmount;
        
        roundedAmount = amount * 100.0;
        roundedAmount += 0.5;
        roundedAmount = (int) roundedAmount;
        roundedAmount = roundedAmount / 100.0;
        return roundedAmount;
    }

    public int getPennies() 
    {
        return myPennies;
    }

    public int getNickels()
    {
        return myNickels;
    }

    public int getDimes()
    {
        return myDimes;
    }

    public int getQuarters()
    {
        return myQuarters;
    }

    public int getHalfDollars()
    {
        return myHalfDollars;
    }

    public int getDollars()
    {
        return myDollars;
    }

    public String getName()
    {
        return MyName;
    }

    


}










